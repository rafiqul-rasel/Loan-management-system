@extends('layouts.frontend')
@section('content')
    <!-- Hero Area Slider -->
    <section id="hero-area" class="hero-area overlay">
        <!-- Slider Area -->
        <div class="slider-active">
            <div class="single-slider overlay" style="background-image:url('{{asset("frontend/images/slider/bg-2.jpg")}}')">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="hero-inner">
                                <!-- Welcome Text -->
                                <div class="welcome-text">
                                    <h1>Let's Discover <span>the world Together!</span></h1>
                                    <p>
                                        <span><i class="icofont-airplane"></i>Over 350 Airlines</span>
                                        <span><i class="icofont-location-pin"></i>More Than 10,000 places</span>
                                        <span><i class="icofont-verification-check"></i>Best Price guarantee</span>
                                    </p>
                                    <!-- Button -->
                                    <div class="button">
                                        <a href="trip-3-column.html" class="btn">Book your Trip</a>
                                        <a href="contact.html" class="btn primary">Contact Us</a>
                                    </div>
                                    <!--/ End Button -->
                                </div>
                                <!--/ End Welcome Text -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider overlay" style="background-image:url('{{asset("frontend/images/slider/bg-3.jpg")}}')">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="hero-inner">
                                <!-- Welcome Text -->
                                <div class="welcome-text">
                                    <h1>Let's Discover <span>the world Together!</span></h1>
                                    <p>
                                        <span><i class="icofont-airplane"></i>Over 350 Airlines</span>
                                        <span><i class="icofont-location-pin"></i>More Than 10,000 places</span>
                                        <span><i class="icofont-verification-check"></i>Best Price guarantee</span>
                                    </p>
                                    <!-- Button -->
                                    <div class="button">
                                        <a href="trip-3-column.html" class="btn">Book your Trip</a>
                                        <a href="contact.html" class="btn primary">Contact Us</a>
                                    </div>
                                    <!--/ End Button -->
                                </div>
                                <!--/ End Welcome Text -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Slider Area -->
    </section>
    <!--/ End Hero Area Slider -->

    <!-- Trip Search -->
    <section class="trip-main style2">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Trip Search -->
                    <div class="trip-search">
                        <form class="form">
                            <h2><span>Find your dream trip</span></h2>
                            <!-- Single Form -->
                            <div class="form-group">
                                <h4>Destination</h4>
                                <div class="nice-select form-control wide" tabindex="0"><span class="current"><i class="icofont-location-pin"></i>Where to Go</span>
                                    <ul class="list">
                                        <li data-value="1" class="option selected ">London City</li>
                                        <li data-value="2" class="option">New York City</li>
                                        <li data-value="3" class="option">Pattaya Singapore</li>
                                        <li data-value="3" class="option">Hatirzeel Dhaka</li>
                                    </ul>
                                </div>
                            </div>
                            <!--/ End Single Form -->
                            <!-- Single Form -->
                            <div class="form-group">
                                <h4>Activities</h4>
                                <div class="nice-select form-control wide" tabindex="0"><span class="current"><i class="icofont-hill"></i>What to do</span>
                                    <ul class="list">
                                        <li data-value="1" class="option selected ">Activities One</li>
                                        <li data-value="2" class="option">Activities Two</li>
                                        <li data-value="3" class="option">Activities Three</li>
                                    </ul>
                                </div>
                            </div>
                            <!--/ End Single Form -->
                            <!-- Single Form -->
                            <div class="form-group duration">
                                <h4>Duration</h4>
                                <div class="nice-select form-control wide" tabindex="0"><span class="current"><i class="icofont-calendar"></i>Duration</span>
                                    <ul class="list">
                                        <li data-value="1" class="option selected ">2 Days</li>
                                        <li data-value="2" class="option">1 Week</li>
                                        <li data-value="3" class="option">1 Month</li>
                                    </ul>
                                </div>
                            </div>
                            <!--/ End Single Form -->
                            <!-- Form Button -->
                            <div class="form-group button">
                                <button type="submit" class="btn">Search Trip</button>
                            </div>
                            <!--/ End Form Button -->
                        </form>
                    </div>
                    <!--/ End Trip Search -->
                </div>
            </div>
        </div>
    </section>
    <!-- End Trip Search -->

    <!-- Why Choose -->
    <section id="why-choose" class="why-choose section">
        <div class="container">
            <div class="row">
                <div class="col-12 wow zoomIn" data-wow-delay="0.4s">
                    <div class="title-line center">
                        <h2><span>Why Choose</span> Us?</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-7 col-12">
                    <div class="row">
                        <div class="col-6 col-md-6 col-12 wow fadeInLeft" data-wow-delay="0.4s">
                            <!-- Choose Single -->
                            <div class="choose-single">
                                <i class="icofont-lock"></i>
                                <div class="content">
                                    <h4>Secure Online transaction</h4>
                                    <p>Security and privacy of your transaction are 100% protected by travelia authorized.</p>
                                </div>
                            </div>
                            <!--/ End Choose Single -->
                        </div>
                        <div class="col-6 col-md-6 col-12 wow fadeInLeft" data-wow-delay="0.6s">
                            <!-- Choose Single -->
                            <div class="choose-single">
                                <i class="icofont-notebook"></i>
                                <div class="content">
                                    <h4>Manage bookings online</h4>
                                    <p>Security and privacy of your transaction are 100% protected by travelia authorized.</p>
                                </div>
                            </div>
                            <!--/ End Choose Single -->
                        </div>
                        <div class="col-6 col-md-6 col-12 wow fadeInLeft" data-wow-delay="0.8s">
                            <!-- Choose Single -->
                            <div class="choose-single">
                                <i class="icofont-search-2"></i>
                                <div class="content">
                                    <h4>Most extensive search</h4>
                                    <p>Security and privacy of your transaction are 100% protected by travelia authorized.</p>
                                </div>
                            </div>
                            <!--/ End Choose Single -->
                        </div>
                        <div class="col-6 col-md-6 col-12 wow fadeInLeft" data-wow-delay="1s">
                            <!-- Choose Single -->
                            <div class="choose-single">
                                <i class="icofont-headphone-alt"></i>
                                <div class="content">
                                    <h4>Customer service</h4>
                                    <p>Security and privacy of your transaction are 100% protected by travelia authorized.</p>
                                </div>
                            </div>
                            <!--/ End Choose Single -->
                        </div>
                        <div class="col-6 col-md-6 col-12 wow fadeInLeft" data-wow-delay="1.2s">
                            <!-- Choose Single -->
                            <div class="choose-single">
                                <i class="icofont-lock"></i>
                                <div class="content">
                                    <h4>Secure Online transaction</h4>
                                    <p>Security and privacy of your transaction are 100% protected by travelia authorized.</p>
                                </div>
                            </div>
                            <!--/ End Choose Single -->
                        </div>
                        <div class="col-6 col-md-6 col-12 wow fadeInLeft" data-wow-delay="1.4s">
                            <!-- Choose Single -->
                            <div class="choose-single">
                                <i class="icofont-notebook"></i>
                                <div class="content">
                                    <h4>Manage your bookings</h4>
                                    <p>Security and privacy of your transaction are 100% protected by travelia authorized.</p>
                                </div>
                            </div>
                            <!--/ End Choose Single -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-12 wow fadeInRight" data-wow-delay="0.6s">
                    <!-- Choose Single -->
                    <div class="why-image overlay">
                        <img src="{{asset('frontend/images/why.jpg')}}" alt="#">
                        <a href="https://www.youtube.com/watch?v=45ETZ1xvHS0" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
                    </div>
                    <!--/ End Choose Single -->
                </div>
            </div>
        </div>
    </section>
    <!-- End Why Choose -->

    <!-- Call To Action -->
    <section id="cta-style" class="cta-style" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="cta-text">
                        <h2><span>Let's go with us</span>Start Your Journey With Us</h2>
                        <p>Necessitatibus enim corrupti ullam voluptatum provident deserunt natus reprehenderit, inventore, tempore aut neque cupiditate, aspernatur! Quibusdam aliquid dolor a culpa, officiis quisquam.</p>
                        <div class="button wow zoomIn" data-wow-delay="1s">
                            <a href="contact.html" class="btn">Book your trip</a>
                            <a href="contact.html" class="btn primary">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Call To Action -->

    <!-- Popular Trips -->
    <section id="popular-trips" class="popular-trips section">
        <div class="container">
            <div class="row">
                <div class="col-12 wow fadeInLeft" data-wow-delay="0.4s">
                    <div class="title-line center">
                        <h2><span>Tour</span> Package</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="trips-main">
                        <!-- Trips Slider -->
                        <div class="trips-slider">
                            <!-- Single Slider -->
                            <div class="single-slider">
                                <div class="trip-head">
                                    <img src="{{asset('frontend/images/p-package/package1.jpg')}}" alt="#">
                                </div>
                                <div class="trip-details">
                                    <div class="content">
                                        <h4><a href="trip-single.html">City tours in europe, paris</a></h4>
                                        <p class="night"><i class="fa fa-clock-o"></i>5 Nights 4 Days <span>|<i class="icofont-users-alt-2"></i> 3 People</span></p>
                                        <p>There are many variations of the is a passages of lorem ipsum that available majority.</p>
                                    </div>
                                    <div class="price">
                                        <a href="trip-single.html" class="btn">View More</a>
                                        <p>From<span>$300</span></p>
                                    </div>

                                </div>
                            </div>
                            <!--/ End Single Trips -->
                            <!-- Single Slider -->
                            <div class="single-slider">
                                <div class="trip-head">
                                    <img src="{{asset('frontend/images/p-package/package2.jpg')}}" alt="#">
                                </div>
                                <div class="trip-details">
                                    <div class="content">
                                        <h4><a href="trip-single.html">Amazon to the Andes</a></h4>
                                        <p class="night"><i class="fa fa-clock-o"></i>3 Nights 4 Days <span>|<i class="icofont-users-alt-2"></i> 7 People</span></p>
                                        <p>There are many variations of the is a passages of lorem ipsum that available majority.</p>
                                    </div>
                                    <div class="price">
                                        <a href="trip-single.html" class="btn">View More</a>
                                        <p>From<span>$300</span></p>
                                    </div>

                                </div>
                            </div>
                            <!--/ End Single Trips -->
                            <!-- Single Slider -->
                            <div class="single-slider">
                                <div class="trip-head">
                                    <div class="trip-offer">25% OFF</div>
                                    <img src="{{asset('frontend/images/p-package/package3.jpg')}}" alt="#">
                                </div>
                                <div class="trip-details">
                                    <div class="content">
                                        <h4><a href="trip-single.html">Mesican Holiday Tour</a></h4>
                                        <p class="night"><i class="fa fa-clock-o"></i>4 Nights 3 Days <span>|<i class="icofont-users-alt-2"></i> 7 People</span></p>
                                        <p>There are many variations of the is a passages of lorem ipsum that available majority.</p>
                                    </div>
                                    <div class="price">
                                        <a href="trip-single.html" class="btn">View More</a>
                                        <p>From<span>$300</span></p>
                                    </div>

                                </div>
                            </div>
                            <!--/ End Single Trips -->
                            <!-- Single Slider -->
                            <div class="single-slider">
                                <div class="trip-head">
                                    <img src="{{asset('frontend/images/p-package/package2.jpg')}}" alt="#">
                                </div>
                                <div class="trip-details">
                                    <div class="content">
                                        <h4><a href="trip-single.html">Amazon to the Andes</a></h4>
                                        <p class="night"><i class="fa fa-clock-o"></i>3 Nights 4 Days <span>|<i class="icofont-users-alt-2"></i> 7 People</span></p>
                                        <p>There are many variations of the is a passages of lorem ipsum that available majority.</p>
                                    </div>
                                    <div class="price">
                                        <a href="trip-single.html" class="btn">View More</a>
                                        <p>From<span>$300</span></p>
                                    </div>

                                </div>
                            </div>
                            <!--/ End Single Trips -->
                        </div>
                        <!--/ End Trips Slider -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Popular Trips -->

    <!-- Counter -->
    <section id="counter" class="counter overlay section" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Single Count -->
                    <div class="single-count">
                        <i class="icofont-ui-user-group"></i>
                        <h2><span class="number">2500</span> Customers</h2>
                    </div>
                    <!--/ End Single Count -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Single Count -->
                    <div class="single-count">
                        <i class="icofont-airplane-alt"></i>
                        <h2><span class="number">5533</span> Destinations</h2>
                    </div>
                    <!--/ End Single Count -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Single Count -->
                    <div class="single-count">
                        <i class="icofont-island"></i>
                        <h2><span class="number">232</span> Tours</h2>
                    </div>
                    <!--/ End Single Count -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Single Count -->
                    <div class="single-count">
                        <i class="icofont-bus-alt-1"></i>
                        <h2><span class="number">542</span> Tour Types</h2>
                    </div>
                    <!--/ End Single Count -->
                </div>
            </div>
        </div>
    </section>
    <!--/ End Counter -->

    <!-- Popular Destinations -->
    <section id="popular-destinations" class="popular-destinations section style2 "  data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row">
                <div class="col-12 wow fadeInRight">
                    <div class="title-line center">
                        <h2><span>Popular</span> Destinations</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="destinations-slider">
                        <!-- Single Slider -->
                        <div class="single-slider">
                            <img src="{{asset('frontend/images/p-destination/d-image1.jpg')}}">
                            <div class="content">
                                <p class="location">austria, switzerland <span>8 days</span></p>
                                <p class="price"><span>From 2000$</span></p>
                            </div>
                        </div>
                        <!-- /End Single Slider -->
                        <!-- Single Slider -->
                        <div class="single-slider">
                            <img src="{{asset('frontend/images/p-destination/d-image2.jpg')}}">
                            <div class="content">
                                <p class="location">grand spain madrid <span>9 days</span></p>
                                <p class="price"><span>From 4000$</span></p>
                            </div>
                        </div>
                        <!-- /End Single Slider -->
                        <!-- Single Slider -->
                        <div class="single-slider">
                            <img src="{{asset('frontend/images/p-destination/d-image3.jpg')}}">
                            <div class="content">
                                <p class="location">grand italy <span>8 days</span></p>
                                <p class="price"><span>From 500$</span></p>
                            </div>
                        </div>
                        <!-- /End Single Slider -->
                        <!-- Single Slider -->
                        <div class="single-slider">
                            <img src="{{asset('frontend/images/p-destination/d-image4.jpg')}}">
                            <div class="content">
                                <p class="location">grand spain madrid <span>9 days</span></p>
                                <p class="price"><span>From 4000$</span></p>
                            </div>
                        </div>
                        <!-- /End Single Slider -->
                        <!-- Single Slider -->
                        <div class="single-slider">
                            <img src="{{asset('frontend/images/p-destination/d-image5.jpg')}}">
                            <div class="content">
                                <p class="location">grand italy <span>8 days</span></p>
                                <p class="price"><span>From 500$</span></p>
                            </div>
                        </div>
                        <!-- /End Single Slider -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Popular Destinations -->

    <!-- Testimonials -->
    <section id="testimonials" class="testimonials overlay section wow fadeInUp" data-wow-delay="0.4s" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="testimonial-slider-two">
                        <!-- Single Slider -->
                        <div class="single-slider">
                            <div class="author">
                                <img src="{{asset('frontend/images/t1.jpg')}}" alt="#">
                                <h2><i class="icofont-quote-left"></i>Tony McLaren<i class="icofont-quote-right"></i><span>Middlesex, Uk</span></h2>
                            </div>
                            <div class="t-content">
                                <p>ultricies. Phasellus At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti providen"</p>
                            </div>
                        </div>
                        <!--/ End Single Slider -->
                        <!-- Single Slider -->
                        <div class="single-slider">
                            <div class="author">
                                <img src="{{asset('frontend/images/t2.jpg')}}" alt="#">
                                <h2><i class="icofont-quote-left"></i>Tony McLaren<i class="icofont-quote-right"></i><span>Middlesex, Uk</span></h2>
                            </div>
                            <div class="t-content">
                                <p>ultricies. Phasellus At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti providen"</p>
                            </div>
                        </div>
                        <!--/ End Single Slider -->
                        <!-- Single Slider -->
                        <div class="single-slider">
                            <div class="author">
                                <img src="{{asset('frontend/images/t3.jpg')}}" alt="#">
                                <h2><i class="icofont-quote-left"></i>Tony McLaren<i class="icofont-quote-right"></i><span>Middlesex, Uk</span></h2>
                            </div>
                            <div class="t-content">
                                <p>ultricies. Phasellus At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti providen"</p>
                            </div>
                        </div>
                        <!--/ End Single Slider -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Testimonials -->

    <!-- Blog -->
    <section class="blog section">
        <div class="container">
            <div class="row">
                <div class="col-12 wow fadeInLeft">
                    <div class="title-line center">
                        <h2><span>Latest</span> Blogs</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="single-news">
                        <div class="news-head">
                            <img src="{{asset('frontend/images/blog/b1.jpg')}}" alt="#">
                        </div>
                        <div class="news-body">
                            <div class="news-content">
                                <h2><a href="#">We are awesome tour company.</a></h2>
                                <div class="date-author">
                                    <p class="date"><i class="icofont-calendar"></i>18 December, 2018</p>
                                    <p class="author"><span>|</span><i class="icofont-user-alt-3"></i>Travelia</p>
                                </div>
                                <p class="text">Lorem ipsum dolor a sit ameti, consectetur adipisicing elit, sed do eiusmod tempor incididunt sed do incididunt sed.</p>
                                <a href="#" class="btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="0.6s">
                    <div class="single-news">
                        <div class="news-head">
                            <img src="{{asset('frontend/images/blog/b2.jpg')}}" alt="#">
                        </div>
                        <div class="news-body">
                            <div class="news-content">
                                <h2><a href="#">Check our all tour package</a></h2>
                                <div class="date-author">
                                    <p class="date"><i class="icofont-calendar"></i>18 December, 2018</p>
                                    <p class="author"><span>|</span><i class="icofont-user-alt-3"></i>Travelia</p>
                                </div>
                                <p class="text">Lorem ipsum dolor a sit ameti, consectetur adipisicing elit, sed do eiusmod tempor incididunt sed do incididunt sed.</p>
                                <a href="#" class="btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="0.8s">
                    <div class="single-news">
                        <div class="news-head">
                            <img src="{{asset('frontend/images/blog/b3.jpg')}}" alt="#">
                        </div>
                        <div class="news-body">
                            <div class="news-content">
                                <h2><a href="#">Find your dream tour by one click.</a></h2>
                                <div class="date-author">
                                    <p class="date"><i class="icofont-calendar"></i>18 December, 2018</p>
                                    <p class="author"><span>|</span><i class="icofont-user-alt-3"></i>Travelia</p>
                                </div>
                                <p class="text">Lorem ipsum dolor a sit ameti, consectetur adipisicing elit, sed do eiusmod tempor incididunt sed do incididunt sed.</p>
                                <a href="#" class="btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Blog -->
            </div>
        </div>
    </section>
    <!-- End Blog -->

@endsection
